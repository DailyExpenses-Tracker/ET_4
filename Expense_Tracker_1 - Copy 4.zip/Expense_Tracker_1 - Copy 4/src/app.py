import streamlit as st
# Set page config
# st.set_page_config(page_title="Daily Expense Tracker", layout="wide")

from utils.signup_app import login_register_ui
from utils.pf import main as pf_main
from utils.logout import logout








# Initialize session state
if "login" not in st.session_state:
    st.session_state.login = False
if "user_id" not in st.session_state:
    st.session_state.user_id = None
if "user_profile" not in st.session_state:
    st.session_state.user_profile = {}
if "expenses" not in st.session_state:
    st.session_state.expenses = []
if 'expenses' not in st.session_state:
    st.session_state.expenses = []
if 'user_id' not in st.session_state:
    st.session_state.user_id = "user_123"  # Replace with actual user ID logic
if 'user_profile' not in st.session_state:
    st.session_state.user_profile = {
        "Full Name": "John Doe",
        "Email": "john@example.com",
        "Mobile": "1234567890",
        #"Registration Date": str(date.today()),
        "Status": "Active"
    }


# Main function
def main():
    if st.session_state.login:
        # User is logged in, show dashboard from pf.py
        pf_main()
    else:
        # User is not logged in, show login/register UI
        login_register_ui()

if __name__ == "__main__":
    main()