import streamlit as st
import streamlit.components.v1 as components  # For potential JavaScript injection if needed later
import sqlite3
import bcrypt
from datetime import date, timedelta
import pandas as pd
from io import BytesIO
from fpdf import FPDF
import json
import os
import uuid
from .signup_app import reset_password, reset_email
import plotly.express as px  # Added for interactive graphs

# Save Expenses
def save_expenses(expenses, user_id):
    filename = f"expenses_{user_id}.json"
    with open(filename, "w") as f:
        json.dump(expenses, f, default=str)

# Save Profile
def save_profile(profile, user_id):
    filename = f"profile_{user_id}.json"
    with open(filename, "w") as f:
        json.dump(profile, f)

# Calculate Dashboard Summary
def calculate_summary(expenses):
    today = date.today()
    summary = {
        "today": 0,
        "yesterday": 0,
        "last_7_days": 0,
        "last_30_days": 0,
        "year_total": 0,
        "total": 0
    }

    for exp in expenses:
        exp_date = exp["date"]
        amount = exp["amount"]
        days_diff = (today - exp_date).days

        summary["total"] += amount
        if exp_date == today:
            summary["today"] += amount
        if exp_date == today - timedelta(days=1):
            summary["yesterday"] += amount
        if 0 <= days_diff < 7:
            summary["last_7_days"] += amount
        if 0 <= days_diff < 30:
            summary["last_30_days"] += amount
        if exp_date.year == today.year:
            summary["year_total"] += amount

    return summary

# Create PDF for Expense Report
def create_pdf(dataframe):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Expense Report", ln=True, align='C')
    pdf.ln(10)

    col_width = pdf.w / 4.5
    row_height = pdf.font_size * 1.5

    # Header
    for col in dataframe.columns:
        pdf.cell(col_width, row_height, col, border=1)
    pdf.ln(row_height)

    # Rows
    for index, row in dataframe.iterrows():
        for item in row:
            pdf.cell(col_width, row_height, str(item), border=1)
        pdf.ln(row_height)

    pdf_output = pdf.output(dest='S').encode('latin1')
    return BytesIO(pdf_output)

# Dashboard Card HTML
def card(title, value):
    return """
        <div class="expense-card" style='
            background:#E1BEE7;
            padding: 25px;
            margin-bottom: 30px;
            margin-top: 30px;
            margin-right: 20px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border: 3px solid #AB47BC;
            transition: all 0.3s ease;'>
            <h4 style='color: black;'>{title}</h4>
            <div style='font-size: 30px; font-weight: bold; color: #AB47BC;'>₹{value}</div>
        </div>
    """.format(title=title, value=value)

# Main Dashboard Function
def main():
    # Sidebar
    with st.sidebar:
        # Custom CSS styles
        st.markdown("""
            <style>
                /* Full app background */
                .main-container {
                    background-color: #f4ecf7;
                    padding: 2rem;
                    border-radius: 25px;
                    max-width: 100% !important
                }

                /* Streamlit's main area */
                .block-container {
                    background-color: #f4ecf7;
                    border-radius: 25px;
                    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
                }
                
                /* Card glow effect on hover */
                .expense-card {
                    transition: all 0.3s ease;
                }
                .expense-card:hover {
                    box-shadow: 0 0 15px 5px rgba(171, 71, 188, 0.6) !important; /* Glow effect */
                    transform: translateY(-5px); /* Slight lift */
                }
                
                /* Style the horizontal line in the sidebar */
                section[data-testid="stSidebar"] hr {
                    border: none; /* Remove default border */
                    height: 3px; /* Make the line thicker */
                    background-color: #FFFFFF; /* Set line color to white */
                    margin: 20px 0; /* Adjust spacing */
                }
                
                section[data-testid="stSidebar"] {
                    background-color: #7d3c98;  
                    border-radius: 25px;
                }
                
                /* Style for clickable labels in the sidebar */
                .sidebar-option {
                    display: flex;
                    align-items: center;
                    padding: 15px 40px;
                    margin-bottom: 10px;
                    border-radius: 10px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                .sidebar-option:hover {
                    background-color: #AB47BC; /* Hover effect */
                }
                .sidebar-option span {
                    color: white !important;
                    font-size: 25px;
                    font-weight: bold;
                    margin-left: 10px;
                }
                .sidebar-option.active {
                    background-color: #AB47BC; /* Highlight the active option */
                }

                /* Style for sub-options in the sidebar */
                .sidebar-sub-option {
                    display: flex;
                    align-items: center;
                    padding: 10px 40px 10px 60px; /* Indent sub-options */
                    margin-bottom: 5px;
                    border-radius: 10px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                .sidebar-sub-option:hover {
                    background-color: #AB47BC; /* Hover effect */
                }
                .sidebar-sub-option span {
                    color: white !important;
                    font-size: 20px; /* Slightly smaller than main options */
                    font-weight: bold;
                    margin-left: 10px;
                }
                .sidebar-sub-option.active {
                    background-color: #AB47BC; /* Highlight the active sub-option */
                }
            </style>
        """, unsafe_allow_html=True)

        st.markdown("<h2 style='color: white;font-size:30px;font-style:bold'>DAILY EXPENSE TRACKER</h2>", unsafe_allow_html=True)
        username = st.session_state.get('username', 'User')
        st.markdown(
            f"""
            <div style='text-align: center; margin-top: 10px;'>
                <span style='font-size: 25px; font-weight: bold; color: white;'>{username}</span>
                <span style='font-size: 25px; color: white;'> - Online</span>
            </div>
            """,
            unsafe_allow_html=True
        )
        st.markdown("---")

        # Define menu options
        menu = ["🏠Dashboard", "💸Expenses", "📊Expense Report", "👤Profile", "🔐Change Password", "🔓Logout"]
        
        # Initialize session state for the selected option
        if 'selected_option' not in st.session_state:
            st.session_state.selected_option = "🏠Dashboard"  # Default to Dashboard

        # Initialize session state for the expense sub-option
        if 'expense_sub_option' not in st.session_state:
            st.session_state.expense_sub_option = "Add Expense"  # Default to Add Expense

        # Create clickable labels for each menu option
        for option in menu:
            # Determine if this option is the currently selected one
            is_active = "active" if st.session_state.selected_option == option else ""
            
            # Create a clickable label using st.button
            if st.button(
                f"{option}",
                key=f"sidebar_{option}",
                use_container_width=True
            ):
                st.session_state.selected_option = option
                # Reset expense sub-option when switching sections
                if option != "💸Expenses":
                    st.session_state.expense_sub_option = "Add Expense"
                st.rerun()  # Rerun the app to update the page

            # Use HTML to style the button as a label
            st.markdown(
                f"""
                <style>
                    button[kind="secondary"][key="sidebar_{option}"] {{
                        background: white !important;
                        border: none !important;
                        padding: 15px 40px !important;
                        margin-bottom: 10px !important;
                        border-radius: 10px !important;
                        cursor: pointer !important;
                        display: flex !important;
                        align-items: center !important;
                        width: 100% !important;
                        text-align: left !important;
                        transition: all 0.3s ease !important;
                    }}
                    button[kind="secondary"][key="sidebar_{option}"]:hover {{
                        background-color: #AB47BC !important;
                    }}
                    button[kind="secondary"][key="sidebar_{option}"] span {{
                        color: white !important;
                        font-size: 25px !important;
                        font-weight: bold !important;
                    }}
                    button[kind="secondary"][key="sidebar_{option}"].{is_active} {{
                        background-color: #AB47BC !important;
                    }}
                </style>
                """,
                unsafe_allow_html=True
            )

            # Show sub-options under Expenses when it is active
            if option == "💸Expenses" and st.session_state.selected_option == "💸Expenses":
                sub_options = ["Add Expense", "View Expenses"]
                for sub_opt in sub_options:
                    # Determine if this sub-option is the currently selected one
                    is_sub_active = "active" if st.session_state.expense_sub_option == sub_opt else ""
                    
                    # Create a clickable label for the sub-option
                    if st.button(
                        f"  {sub_opt}",  # Add indentation with spaces for visual hierarchy
                        key=f"sub_{sub_opt.replace(' ', '_')}",
                        use_container_width=True
                    ):
                        st.session_state.expense_sub_option = sub_opt
                        st.rerun()

                    # Style the sub-option button
                    st.markdown(
                        f"""
                        <style>
                            button[kind="secondary"][key="sub_{sub_opt.replace(' ', '_')}"] {{
                                background: none !important;
                                border: none !important;
                                padding: 10px 40px 10px 60px !important; /* Indent sub-options */
                                margin-bottom: 5px !important;
                                border-radius: 10px !important;
                                cursor: pointer !important;
                                display: flex !important;
                                align-items: center !important;
                                width: 100% !important;
                                text-align: left !important;
                                transition: all 0.3s ease !important;
                            }}
                            button[kind="secondary"][key="sub_{sub_opt.replace(' ', '_')}"]:hover {{
                                background-color: #AB47BC !important;
                            }}
                            button[kind="secondary"][key="sub_{sub_opt.replace(' ', '_')}"] span {{
                                color: white !important;
                                font-size: 20px !important; /* Slightly smaller */
                                font-weight: bold !important;
                            }}
                            button[kind="secondary"][key="sub_{sub_opt.replace(' ', '_')}"].{is_sub_active} {{
                                background-color: #AB47BC !important;
                            }}
                        </style>
                        """,
                        unsafe_allow_html=True
                    )

        # Assign the selected option to choice
        choice = st.session_state.selected_option

    # Dashboard
    if choice == "🏠Dashboard":
        st.markdown("<h2 style='font-size:100px;font-style:bold'>Dashboard</h2>", unsafe_allow_html=True)
        summary = calculate_summary(st.session_state.expenses)

        col1, col2, col3, col4 = st.columns(4)
        col5, col6 = st.columns(2)

        with col1:
            st.markdown(card("Today's Expense", summary["today"]), unsafe_allow_html=True)
        with col2:
            st.markdown(card("Yesterday's Expense", summary["yesterday"]), unsafe_allow_html=True)
        with col3:
            st.markdown(card("Last 7 Days Expenses", summary["last_7_days"]), unsafe_allow_html=True)
        with col4:
            st.markdown(card("Last 30 Days Expenses", summary["last_30_days"]), unsafe_allow_html=True)
        with col5:
            st.markdown(card("Current Year Expenses", summary["year_total"]), unsafe_allow_html=True)
        with col6:
            st.markdown(card("Total Expenses", summary["total"]), unsafe_allow_html=True)

    # Expenses
    elif choice == "💸Expenses":
        st.markdown("<h2>Expenses</h2>", unsafe_allow_html=True)

        # Use the selected sub-option
        sub_opt = st.session_state.expense_sub_option

        if sub_opt == "Add Expense":
            st.subheader("Add New Expense")
            expense_date = st.date_input("Date", date.today())
            category = st.selectbox("Category", ["Food", "Transport", "Shopping", "Bills", "Others"])
            amount = st.number_input("Amount", min_value=0.0)

            if st.button("Add Expense"):
                new_expense = {
                    "id": str(uuid.uuid4()),
                    "date": expense_date,
                    "category": category,
                    "amount": amount
                }
                st.session_state.expenses.append(new_expense)
                save_expenses(st.session_state.expenses, st.session_state.user_id)
                st.success(f"Expense of ₹{amount} added under {category} for {expense_date}")

        elif sub_opt == "View Expenses":
            st.subheader("View Expenses")

            if st.session_state.expenses:
                table_data = []
                for idx, exp in enumerate(st.session_state.expenses, start=1):
                    table_data.append({
                        "S.No": idx,
                        "Date": exp["date"],
                        "Category": exp["category"],
                        "Amount (₹)": exp["amount"],
                        "ID": exp["id"],
                    })
                df = pd.DataFrame(table_data)

                st.markdown("""
                    <style>
                        table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-top: 20px;
                            background-color: #f9f9f9;
                        }
                        th, td {
                            padding: 12px;
                            text-align: center;
                            border: 1px solid #ddd;
                            font-size: 14px;
                        }
                        th {
                            background-color: #4CAF50;
                            color: white;
                            font-weight: bold;
                        }
                        tr:nth-child(even) {
                            background-color: #f2f2f2;
                        }
                        tr:hover {
                            background-color: #ddd;
                        }
                        td {
                            color: #333;
                        }
                    </style>
                """, unsafe_allow_html=True)

                cols = st.columns([1, 2, 2, 2, 1])
                headers = ["S.No", "Date", "Category", "Amount (₹)", "Action"]
                for idx, header in enumerate(headers):
                    cols[idx].markdown(f"**{header}**", unsafe_allow_html=True)

                for index, row in df.iterrows():
                    row_cols = st.columns([1, 2, 2, 2, 1])
                    row_cols[0].write(row["S.No"])
                    row_cols[1].write(row["Date"])
                    row_cols[2].write(row["Category"])
                    row_cols[3].write(f"₹{row['Amount (₹)']}")
                    if row_cols[4].button("Delete", key=f"del_{row['ID']}"):
                        st.session_state.expenses = [e for e in st.session_state.expenses if e["id"] != row["ID"]]
                        save_expenses(st.session_state.expenses, st.session_state.user_id)
                        st.success("Expense deleted successfully.")
                        st.rerun()

            else:
                st.info("No expenses added yet.")

    # Expense Report
    elif choice == "📊Expense Report":
        st.markdown("<h2>Expense Report</h2>", unsafe_allow_html=True)
        report_type = st.selectbox("Report Type", ["Daywise", "Weekwise", "Monthwise", "Yearwise"])
        start_date = st.date_input("Start Date", date.today() - timedelta(days=7))
        end_date = st.date_input("End Date", date.today())
        filtered = [e for e in st.session_state.expenses if start_date <= e["date"] <= end_date]

        if filtered:
            df = pd.DataFrame(filtered)
            df["date"] = pd.to_datetime(df["date"])
            df["year"] = df["date"].dt.year
            df["month"] = df["date"].dt.strftime("%Y-%m")
            df["week"] = df["date"].dt.strftime("%Y-W%U")  # Week number with year

            if report_type == "Daywise":
                df_grouped = df.groupby("date")["amount"].sum().reset_index()
                df_grouped["date"] = df_grouped["date"].dt.strftime("%Y/%m/%d")
            elif report_type == "Weekwise":
                df_grouped = df.groupby("week")["amount"].sum().reset_index().rename(columns={"week": "Week"})
            elif report_type == "Monthwise":
                df_grouped = df.groupby("month")["amount"].sum().reset_index().rename(columns={"month": "Month"})
            else:
                df_grouped = df.groupby("year")["amount"].sum().reset_index().rename(columns={"year": "Year"})
                df_grouped["Year"] = df_grouped["Year"].astype(str)

            label_col = df_grouped.columns[0]
            df_grouped.columns = [label_col, "Total Expense"]
            st.dataframe(df_grouped)
            st.write(f"**Grand Total: ₹{df_grouped['Total Expense'].sum()}**")

            # Interactive Bar Graph
            st.subheader("Expense Trend")
            fig_bar = px.bar(
                df_grouped,
                x=label_col,
                y="Total Expense",
                title=f"{report_type} Expense Trend",
                labels={"Total Expense": "Amount (₹)", label_col: report_type},
                color="Total Expense",
                color_continuous_scale=px.colors.sequential.Viridis
            )
            fig_bar.update_layout(xaxis_title=report_type, yaxis_title="Amount (₹)", showlegend=False)
            st.plotly_chart(fig_bar, use_container_width=True)

            # Interactive Donut Chart (Category-wise)
            st.subheader("Expense Distribution by Category")
            df_category = df.groupby("category")["amount"].sum().reset_index()
            fig_donut = px.pie(
                df_category,
                names="category",
                values="amount",
                title="Expense Distribution by Category",
                hole=0.4,
                color_discrete_sequence=px.colors.qualitative.Plotly
            )
            fig_donut.update_traces(textinfo="percent+label", pull=[0.1] * len(df_category))
            fig_donut.update_layout(showlegend=True)
            st.plotly_chart(fig_donut, use_container_width=True)

            # Download CSV
            csv = df_grouped.to_csv(index=False).encode('utf-8')
            st.download_button("Download CSV", data=csv, file_name="expense_report.csv", mime="text/csv")

            # Download PDF
            pdf_data = create_pdf(df_grouped)
            st.download_button("Download PDF", data=pdf_data, file_name="expense_report.pdf", mime="application/pdf")
        else:
            st.info("No expenses to report.")

    # Profile
    elif choice == "👤Profile":
        st.markdown("<h2>Profile</h2>", unsafe_allow_html=True)
        with st.form("profile_form"):
            username = st.session_state.get('username', 'User')
            st.markdown(f"<h2>Welcome {username.upper()}</h2>", unsafe_allow_html=True)
            email = st.text_input("Email", st.session_state.user_profile["Email"])
            mobile = st.text_input("Mobile Number", st.session_state.user_profile["Mobile"])
            registration_date = st.text_input("Registration Date", st.session_state.user_profile["Registration Date"], disabled=True)
            status = st.text_input("Status", st.session_state.user_profile["Status"], disabled=True)
            submitted = st.form_submit_button("Update Profile")
            if submitted:
                st.session_state.user_profile.update({
                    "Email": email,
                    "Mobile": mobile,
                    "Registration Date": registration_date,
                    "Status": status
                })
                reset_email(username, email)
                save_profile(st.session_state.user_profile, st.session_state.user_id)
                st.success("Profile updated successfully!")

    # Change Password
    elif choice == "🔐Change Password":
        st.markdown("<h2>Change Password</h2>", unsafe_allow_html=True)
        old_pwd = st.text_input("Old Password", type="password")
        new_pwd = st.text_input("New Password", type="password")
        email = st.text_input("Email", type="default")
        confirm_pwd = st.text_input("Confirm New Password", type="password")
        if st.button("Update Password"):
            if new_pwd == confirm_pwd and new_pwd != "":
                result = reset_password(new_pass=new_pwd, old_pass=old_pwd, email=email)
                if result:
                    st.session_state.old_pwd = ""
                    st.session_state.new_pwd = ""
                    st.session_state.confirm_pwd = ""
                    st.session_state.email = ""
                    st.success("Password changed successfully.")
                    from utils.logout import logout
                    logout()
                else:
                    st.warning("Some issues in password Reset")
            else:
                st.error("Passwords do not match or are empty.")

    # Logout
    elif choice == "🔓Logout":
        from utils.logout import logout
        logout()

if __name__ == "__main__":
    main()