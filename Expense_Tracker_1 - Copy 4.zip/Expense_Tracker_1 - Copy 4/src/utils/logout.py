import streamlit as st

def logout():
    st.session_state.login = False
    st.session_state.user_id = None
    st.session_state.user_profile = {}
    st.session_state.expenses = []
    st.success("You have been logged out.")
    st.rerun()  # Redirect to login page