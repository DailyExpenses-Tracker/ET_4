import streamlit as st
import sqlite3
import bcrypt
import os
import json
import uuid
from datetime import date
import pandas as pd
import re
import uuid
# Constants
DB_FILE = "expense_tracker.db"

# # -----------------------------Database Setup-------------------------------------------
# def init_db():
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         c = conn.cursor()
#         c.execute('''CREATE TABLE IF NOT EXISTS users (
#                         id INTEGER PRIMARY KEY AUTOINCREMENT, 
#                         username TEXT UNIQUE, 
#                         email TEXT, 
#                         password BLOB)''')
#         conn.commit()
#     except sqlite3.Error as e:
#         st.error(f"Database error during initialization: {e}")
#     finally:
#         conn.close()

# init_db()

# # -----------------------------Authentication Functions------------------------------------
# def hash_password(password):
#     return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

# def check_password(password, hashed):
#     return bcrypt.checkpw(password.encode('utf-8'), hashed)

# def register_user(username, email, password):
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         c = conn.cursor()
#         c.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
#                   (username, email, hash_password(password)))
#         conn.commit()
#         return True
#     except sqlite3.IntegrityError:
#         return False  # Username already exists
#     except sqlite3.Error as e:
#         st.error(f"Database error during registration: {e}")
#         return False
#     finally:
#         conn.close()

# def login_user(username, password):
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         c = conn.cursor()
#         c.execute('SELECT id, password FROM users WHERE username = ?', (username,))
#         user = c.fetchone()
#         if user and check_password(password, user[1]):
#             return user[0]
#         return None
#     except sqlite3.Error as e:
#         st.error(f"Database error during login: {e}")
#         return None
#     finally:
#         conn.close()

# # -------------------------------Load/Save Functions---------------------------------
# def load_expenses(user_id):
#     filename = f"expenses_{user_id}.json"
#     if os.path.exists(filename):
#         try:
#             with open(filename, "r") as f:
#                 data = json.load(f)
#                 for exp in data:
#                     exp["date"] = pd.to_datetime(exp["date"]).date()
#                     exp["id"] = exp.get("id", str(uuid.uuid4()))
#                 return data
#         except Exception as e:
#             st.error(f"Error loading expenses: {e}")
#             return []
#     return []

# def load_profile(user_id):
#     filename = f"profile_{user_id}.json"
#     if os.path.exists(filename):
#         try:
#             with open(filename, "r") as f:
#                 return json.load(f)
#         except Exception as e:
#             st.error(f"Error loading profile: {e}")
#     return {
#         "Full Name": "",
#         "Email": "",
#         "Mobile": "",
#         "Registration Date": date.today().strftime("%Y-%m-%d"),
#         "Status": "Active"
#     }

# def reset_password(new_pass, old_pass, email):
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         c = conn.cursor()
#         c.execute('''UPDATE users SET password=? WHERE email=?''', (hash_password(new_pass), email))
#         conn.commit()
#         if c.rowcount == 0:
#             return False
#         return True
#     except Exception as e:
#         print("Error:", e)
#         return False

# def reset_email(username, email):
#     try:
#         conn = sqlite3.connect(DB_FILE)
#         c = conn.cursor()
#         c.execute('''UPDATE users SET email=? WHERE username=?''', (email, username))
#         conn.commit()
#         return True
#     except Exception as e:
#         return False

# # ---------------------------Validate email format-----------------------------
# def is_valid_email(email):
#     pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
#     return re.match(pattern, email) is not None

# # ------------------------------Login/Register UI------------------------------
# def login_register_ui():
#     if "selected_tab" not in st.session_state:
#         st.session_state.selected_tab = "Login"
#     unique_key = f"auth_tab_selector_{uuid.uuid4()}"    
#     st.session_state.selected_tab = st.radio(
#         "Select Option", ["Login", "Register"],
#         index=0 if st.session_state.selected_tab == "Login" else 1,
#         key= unique_key#"auth_tab_selector_unique"
#     )

#     # Apply different CSS styles based on tab
#     st.markdown("""
#     <style>
#     .stApp {
#         background: linear-gradient(135deg, #6a0dad, #d291ff);
#         color: white;
#     }
#     #.form-container {
#      #   background-color: rgba(255, 255, 255, 0.15);
#       #  padding: 40px;
#        # border-radius: 20px;
#     #    box-shadow: 0 4px 20px rgba(0,0,0,0.5);
#      #   width: 40%;
#       #  max-width: 600px;
#        # margin: auto;
#         #margin-top: 50px;
#         #backdrop-filter: blur(15px);
#     #}
#     .title {
#         text-align: center;
#         color: #ffffff;
#         font-size: 32px;
#         font-weight: bold;
#         margin-bottom: 20px;
#     }
#     label, .stTextInput > div > input {
#         color: #ffffff !important;
#     }
#     .stTextInput input {
#         background-color: rgba(255,255,255,0.2);
#         border-radius: 10px;
#     }
#     </style>
#     """, unsafe_allow_html=True)

#     st.markdown("<div class='title'>Daily Expense Tracker</div>", unsafe_allow_html=True)
#     st.markdown("<div class='form-container'>", unsafe_allow_html=True)

#     # ------------------- LOGIN FORM ------------------
#     #unique_key = f"{uuid.uuid4()}"
#     if st.session_state.selected_tab == "Login":
#         st.subheader("Login")
        
#         username = st.text_input("Username", key="login_user"+unique_key)
#         password = st.text_input("Password", type="password", key="login_pass"+unique_key)
#         if st.button("Login", key="login_button"+unique_key):
#             if not username or not password:
#                 st.error("Please enter both username and password.")
#             else:
#                 user_id = login_user(username, password)
#                 if user_id:
#                     st.session_state.login = True
#                     st.session_state.user_id = user_id
#                     st.session_state.username = username
#                     st.session_state.user_profile = load_profile(user_id)
#                     st.session_state.expenses = load_expenses(user_id)
#                     st.success("Login successful!")
#                     st.rerun()
#                 else:
#                     st.error("Invalid username or password.")

#     # ------------------- REGISTER FORM ------------------
#     elif st.session_state.selected_tab == "Register":
#         st.subheader("Register")
#         new_username = st.text_input("Username", key="reg_user"+unique_key)
#         new_email = st.text_input("Email", key="reg_email")
#         new_password = st.text_input("Password", type="password", key="reg_pass"+unique_key)
#         confirm_password = st.text_input("Confirm Password", type="password", key="reg_confirm_pass"+unique_key)
#         if st.button("Register", key="register_button"):
#             if not new_username:
#                 st.error("Username is required.")
#             elif not new_email:
#                 st.error("Email is required.")
#             elif not is_valid_email(new_email):
#                 st.error("Please enter a valid email address.")
#             elif not new_password:
#                 st.error("Password is required.")
#             elif new_password != confirm_password:
#                 st.error("Passwords do not match.")
#             elif len(new_password) < 6:
#                 st.error("Password must be at least 6 characters long.")
#             else:
#                 if register_user(new_username, new_email, new_password):
#                     st.success("Registration successful! Redirecting to login...")
#                     st.session_state.selected_tab = "Login"
#                     st.rerun()
#                 else:
#                     st.error("Username already exists. Please choose a different one.")
    
#     st.markdown("</div>", unsafe_allow_html=True)

# # Run the UI
# #login_register_ui()
import streamlit as st
import sqlite3
import bcrypt
import os
import json
import uuid
from datetime import date
import pandas as pd
import re

# Constants
DB_FILE = os.path.join(os.path.dirname(__file__), "expense_tracker.db")

# -----------------------------Database Setup-------------------------------------------
def init_db():
    try:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT, 
                        username TEXT UNIQUE, 
                        email TEXT, 
                        password BLOB)''')
        conn.commit()
    except sqlite3.Error as e:
        st.error(f"Database error during initialization: {e}")
    finally:
        conn.close()

init_db()

# -----------------------------Authentication Functions------------------------------------
def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

def check_password(password, hashed):
    return bcrypt.checkpw(password.encode('utf-8'), hashed)

def register_user(username, email, password):
    try:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                  (username, email, hash_password(password)))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False  # Username already exists
    except sqlite3.Error as e:
        st.error(f"Database error during registration: {e}")
        return False
    finally:
        conn.close()

def login_user(username, password):
    try:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('SELECT id, password FROM users WHERE username = ?', (username,))
        user = c.fetchone()
        if user and check_password(password, user[1]):
            return user[0]
        return None
    except sqlite3.Error as e:
        st.error(f"Database error during login: {e}")
        return None
    finally:
        conn.close()

# -------------------------------Load/Save Functions---------------------------------
def load_expenses(user_id):
    filename = f"expenses_{user_id}.json"
    if os.path.exists(filename):
        try:
            with open(filename, "r") as f:
                data = json.load(f)
                for exp in data:
                    exp["date"] = pd.to_datetime(exp["date"]).date()
                    exp["id"] = exp.get("id", str(uuid.uuid4()))
                return data
        except Exception as e:
            st.error(f"Error loading expenses: {e}")
            return []
    return []

def load_profile(user_id):
    filename = f"profile_{user_id}.json"
    if os.path.exists(filename):
        try:
            with open(filename, "r") as f:
                return json.load(f)
        except Exception as e:
            st.error(f"Error loading profile: {e}")
    return {
        "Full Name": "",
        "Email": "",
        "Mobile": "",
        "Registration Date": date.today().strftime("%Y-%m-%d"),
        "Status": "Active"
    }

def reset_password(new_pass, old_pass, email):
    try:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''UPDATE users SET password=? WHERE email=?''', (hash_password(new_pass), email))
        conn.commit()
        if c.rowcount == 0:
            return False
        return True
    except Exception as e:
        print("Error:", e)
        return False

def reset_email(username, email):
    try:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''UPDATE users SET email=? WHERE username=?''', (email, username))
        conn.commit()
        return True
    except Exception as e:
        return False

# ---------------------------Validate email format-----------------------------
def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(pattern, email) is not None

# ------------------------------Login/Register UI------------------------------
def login_register_ui():
    if st.session_state.get("login", False):
        return  # Skip rendering if already logged in

    if "selected_tab" not in st.session_state:
        st.session_state.selected_tab = "Login"
        
    st.session_state.selected_tab = st.radio(
        "Select Option", ["Login", "Register"],
        index=0 if st.session_state.selected_tab == "Login" else 1,
        key="auth_tab_selector"
    )

    # Apply CSS styles
    st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(135deg, #6a0dad, #d291ff);
        color: white;
    }
    .form-container {
        background-color: rgba(255, 255, 255, 0.15);
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.5);
        width: 40%;
        max-width: 600px;
        margin: auto;
        margin-top: 50px;
        backdrop-filter: blur(15px);
    }
    .title {
        text-align: center;
        color: #ffffff;
        font-size: 32px;
        font-weight: bold;
        margin-bottom: 20px;
    }
    label, .stTextInput > div > input {
        color: #ffffff !important;
    }
    .stTextInput input {
        background-color: rgba(255,255,255,0.2);
        border-radius: 10px;
    }
    </style>
    """, unsafe_allow_html=True)

    st.markdown("<div class='title'>Daily Expense Tracker</div>", unsafe_allow_html=True)
    st.markdown("<div class='form-container'>", unsafe_allow_html=True)

    # ------------------- LOGIN FORM ------------------
    if st.session_state.selected_tab == "Login":
        st.subheader("Login")
        if "login_username" not in st.session_state:
            st.session_state.login_username = ""
        if "login_password" not in st.session_state:
            st.session_state.login_password = ""

        st.text_input("Username", value=st.session_state.login_username, key="login_user")
        st.text_input("Password", type="password", value=st.session_state.login_password, key="login_pass")
        if st.button("Login", key="login_button"):
            if not st.session_state.login_username or not st.session_state.login_password:
                st.error("Please enter both username and password.")
            else:
                user_id = login_user(st.session_state.login_username, st.session_state.login_password)
                if user_id:
                    st.session_state.login = True
                    st.session_state.user_id = user_id
                    st.session_state.username = st.session_state.login_username
                    st.session_state.user_profile = load_profile(user_id)
                    st.session_state.expenses = load_expenses(user_id)
                    st.success("Login successful!")
                    st.session_state.login_username = ""
                    st.session_state.login_password = ""
                    st.rerun()
                else:
                    st.error("Invalid username or password.")

    # ------------------- REGISTER FORM ------------------
    elif st.session_state.selected_tab == "Register":
        st.subheader("Register")
        # Initialize session state
        if "reg_username" not in st.session_state:
            st.session_state.reg_username = ""
        if "reg_email" not in st.session_state:
            st.session_state.reg_email = ""
        if "reg_password" not in st.session_state:
            st.session_state.reg_password = ""
        if "reg_confirm_password" not in st.session_state:
            st.session_state.reg_confirm_password = ""

        # Use text_input to update session state automatically
        st.text_input("Username", value=st.session_state.reg_username, key="reg_user")
        st.text_input("Email", value=st.session_state.reg_email, key="reg_email")
        st.text_input("Password", type="password", value=st.session_state.reg_password, key="reg_pass")
        st.text_input("Confirm Password", type="password", value=st.session_state.reg_confirm_password, key="reg_confirm_pass")

        # Debug: Display current username value
        st.write(f"Debug: Current reg_username = '{st.session_state.reg_username}'")

        if st.button("Register", key="register_button"):
            # Validate inputs
            if not st.session_state.reg_username:
                st.error("Username is required.")
            elif not st.session_state.reg_email:
                st.error("Email is required.")
            elif not is_valid_email(st.session_state.reg_email):
                st.error("Please enter a valid email address.")
            elif not st.session_state.reg_password:
                st.error("Password is required.")
            elif st.session_state.reg_password != st.session_state.reg_confirm_password:
                st.error("Passwords do not match.")
            elif len(st.session_state.reg_password) < 6:
                st.error("Password must be at least 6 characters long.")
            else:
                # Attempt registration
                if register_user(st.session_state.reg_username, st.session_state.reg_email, st.session_state.reg_password):
                    st.success("Registration successful! Redirecting to login...")
                    st.session_state.selected_tab = "Login"
                    st.session_state.reg_username = ""
                    st.session_state.reg_email = ""
                    st.session_state.reg_password = ""
                    st.session_state.reg_confirm_password = ""
                    st.rerun()
                else:
                    st.error("Username already exists. Please choose a different one.")
    
    st.markdown("</div>", unsafe_allow_html=True)